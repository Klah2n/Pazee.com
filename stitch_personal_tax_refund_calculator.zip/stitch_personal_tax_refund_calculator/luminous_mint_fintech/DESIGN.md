---
name: Luminous Mint Fintech
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#3d4a42'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#6d7a72'
  outline-variant: '#bccac0'
  surface-tint: '#006c4a'
  primary: '#006948'
  on-primary: '#ffffff'
  primary-container: '#00855d'
  on-primary-container: '#f5fff7'
  inverse-primary: '#68dba9'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#006949'
  on-tertiary: '#ffffff'
  tertiary-container: '#00855d'
  on-tertiary-container: '#f5fff7'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#85f8c4'
  primary-fixed-dim: '#68dba9'
  on-primary-fixed: '#002114'
  on-primary-fixed-variant: '#005137'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#68fcbf'
  tertiary-fixed-dim: '#45dfa4'
  on-tertiary-fixed: '#002114'
  on-tertiary-fixed-variant: '#005137'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 3rem
    fontWeight: '700'
    lineHeight: 3.75rem
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 2.25rem
    fontWeight: '700'
    lineHeight: 2.75rem
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.75rem
    fontWeight: '700'
    lineHeight: 2.25rem
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.25rem
    fontWeight: '600'
    lineHeight: 1.75rem
    letterSpacing: -0.005em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 1.125rem
    fontWeight: '400'
    lineHeight: 1.75rem
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 1rem
    fontWeight: '400'
    lineHeight: 1.5rem
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.25rem
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.01em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.75rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.02em
  caption:
    fontFamily: Plus Jakarta Sans
    fontSize: 0.6875rem
    fontWeight: '500'
    lineHeight: 0.875rem
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-sm: 1rem
  margin: 2rem
  margin-sm: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

The brand personality merges regulatory precision with approachable financial clarity. Designed for modern taxpayers, freelancers, and businesses, the interface alleviates tax anxiety through an airy, serene, and ultra-legible presentation. 

### Design Philosophy
- **Modern Minimalist Clarity:** Pure white canvas foundations paired with crystalline surfaces, removing visual friction while managing complex calculation tables and multi-tier tax deductibles.
- **Fresh Botanical Accents:** Gentle mint and emerald touches inject optimism and freshness into otherwise rigid fiscal workflows.
- **Trustworthy & Human:** Soft, generous geometries convey safety and modern compliance without the cold austerity of traditional banking software.

## Colors

The palette balances clean clinical whites with invigorating mint botanicals and deep slate inks for maximum legibility.

### Roles & Semantic Application
- **Primary (`#059669`)**: Anchors primary actions, authoritative figures, active focus rings, and high-impact navigational elements.
- **Secondary (`#10b981`)**: Utilized for positive growth metrics, calculated tax refunds, and primary hover states.
- **Tertiary (`#34d399`)**: Used sparingly for progress tracks, subtle success indicators, and soft chart graphics.
- **Tinted Backdrops (`#ecfdf5`, `#e6f7ef`)**: Provide low-strain card fills, highlight badges, and selected row states.
- **Base Canvas (`#ffffff`)**: Pure white base, emphasizing negative space and crisp container edges.
- **Neutral Primary (`#0f172a`)**: Deep slate for high-contrast primary typography and data values.
- **Neutral Secondary (`#475569`)**: Mid-tone slate for supporting subtitles, form labels, and table metadata.
- **Neutral Surface / Border (`#f1f5f9` / `#e2e8f0`)**: Subtle containment dividers avoiding heavy borders.

## Typography

Plus Jakarta Sans serves as the singular typographic voice across headlines, body, and tabular interfaces. Its geometric underpinnings combined with warm, humanist apertures give financial calculations a modern, welcoming posture while preserving strict baseline alignment.

### Usage Guidelines
- Apply `font-feature-settings: "tnum" 1` to all monetary values, financial tables, and deduction totals to prevent layout shifting across state transitions.
- Maintain tight negative tracking on `display-lg` and `headline-lg` to create refined editorial authority on desktop views.
- Keep `body-md` reserved for instructional copy and narrative summaries, ensuring line lengths remain between 55–75 characters.

## Layout & Spacing

A 12-column responsive fluid grid provides disciplined organization for multi-step tax forms, withholding summaries, and live calculation dashboards.

### Breakpoints & Canvas Flow
- **Mobile (< 768px):** 4 columns, `margin-sm` (1rem), `gutter-sm` (1rem). Dense deduction groups collapse into vertical accordions with full-width primary actions pinned above the viewport bottom edge.
- **Tablet (768px – 1024px):** 8 columns, `margin` (2rem), `gutter` (1.5rem). Split views feature input calculators alongside dynamic refund estimates.
- **Desktop (> 1024px):** 12 columns, max-width constrained to `1280px` centered, `margin` (2rem). Supports multi-pane tax filings, breadcrumbs, and floating contextual audits.

### Rhythmic Rules
- Form fields and related input groups operate on a strict 8px increment.
- Content groupings inside cards utilize `space-lg` (1.5rem) internal padding, collapsing to `space-md` (1rem) on mobile viewports.

## Elevation & Depth

Visual depth is achieved through translucent emerald atmospheric layers, faint boundaries, and soft ambient light rather than stark drop shadows.

### Elevation Levels
- **Level 0 (Base Canvas):** `#ffffff` pure background with no elevation.
- **Level 1 (Default Containers & Cards):** Flat `#ffffff` surface bounded by a razor-thin border (`1px solid #f1f5f9`), grounded by an ultra-diffused emerald ambient shadow: `0 4px 20px -2px rgba(16, 185, 129, 0.04), 0 2px 6px -1px rgba(15, 23, 42, 0.02)`.
- **Level 2 (Hovered Cards & Dropdowns):** Subtle rise using `0 12px 32px -4px rgba(16, 185, 129, 0.08), 0 4px 12px -2px rgba(15, 23, 42, 0.03)`.
- **Level 3 (Modals & Sheet Overlays):** `#ffffff` elevated by `0 24px 48px -12px rgba(15, 23, 42, 0.12)`, backed by a gentle frosted overlay: `rgba(255, 255, 255, 0.8)` with a `backdrop-blur(8px)`.

## Shapes

The design system embraces a balanced `0.5rem` (8px) base curvature, expanding smoothly to `1rem` (16px) for major cards, modals, and metric banners.

### Component Radii Mapping
- **Input Fields, Dropdowns, Segmented Tabs:** `0.5rem` (8px) for an orderly, structured input rhythm.
- **Interactive Badges, Chips, Pills:** Fully rounded `9999px` to distinguish metadata tokens from selectable inputs.
- **Cards, Calculation Panels, Container Modules:** `1rem` (16px) to maintain a soft, friendly, and non-intimidating perimeter.
- **Notification Banners, Deduction Callouts:** `0.75rem` (12px) to softly highlight alerts without disrupting overall layout structure.

## Components

### Buttons
- **Primary:** Background `#059669`, label `#ffffff` (`label-lg`), border `none`. Hover transitions to `#10b981` with a soft `0 4px 14px rgba(5, 150, 105, 0.25)` glow. Active state presses down by `1px`.
- **Secondary / Soft:** Background `#ecfdf5`, label `#059669`, border `1px solid rgba(16, 185, 129, 0.2)`. Hover shifts to `#e6f7ef` with text `#047857`.
- **Ghost:** Background transparent, label `#475569`. Hover reveals `#f8fafc` background with `#0f172a` text.

### Badges & Chips
- **Status Badges:** Fully rounded (`rounded-full`), padding `0.25rem 0.75rem`. Fresh mint fill `#ecfdf5`, text `#059669` (`label-md`), accompanied by an optional 6px pulsing emerald indicator for real-time calculation status.
- **Deduction Filter Chips:** Border `1px solid #e2e8f0`, background `#ffffff`, text `#475569`. When selected, background shifts to `#ecfdf5`, border to `#10b981`, and text to `#059669`.

### Input Fields & Controls
- **Text & Currency Inputs:** Surface `#ffffff`, border `1px solid #e2e8f0`, corner radius `0.5rem`. Currency fields integrate fixed `#475569` currency prefixes. Focus state triggers border `#10b981` with an outer ring `0 0 0 3px rgba(16, 185, 129, 0.15)`.
- **Checkboxes & Radios:** Size `20px x 20px`, border `1.5px solid #cbd5e1`. Checked state transitions instantly to `#059669` fill with a sharp white checkmark or center pip.

### Cards & Financial Containers
- **Metric Cards:** `#ffffff` surface, border `1px solid #f1f5f9`, padding `1.5rem`. Houses tax liability breakdowns, net savings, and deductions.
- **Highlight Metric Panel:** Tinted `#e6f7ef` surface with a gentle gradient fading into `#ffffff`, flanked by a `1px solid rgba(16, 185, 129, 0.2)` border to display total estimated tax refund values.

### Specialized Financial Additions
- **Tax Step Flow Indicator:** Horizontal segment bar featuring numbered circular pins connected by a 2px track that shifts from `#e2e8f0` (upcoming) to `#059669` (completed).
- **Audit Flag Callout:** Soft amber-tinted or mint-tinted warning card with an icon anchor, detailing automated compliance validation checks without alarming the user.