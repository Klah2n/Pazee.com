---
name: SiamTax Smart Calc
colors:
  surface: '#f8f9ff'
  surface-dim: '#ccdbf4'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e6eeff'
  surface-container-high: '#dde9ff'
  surface-container-highest: '#d5e3fd'
  on-surface: '#0d1c2f'
  on-surface-variant: '#43474d'
  inverse-surface: '#233144'
  inverse-on-surface: '#ebf1ff'
  outline: '#74777e'
  outline-variant: '#c3c6ce'
  surface-tint: '#49607c'
  primary: '#001428'
  on-primary: '#ffffff'
  primary-container: '#0f2942'
  on-primary-container: '#7991af'
  inverse-primary: '#b0c9e8'
  secondary: '#006a61'
  on-secondary: '#ffffff'
  secondary-container: '#86f2e4'
  on-secondary-container: '#006f66'
  tertiary: '#090051'
  on-tertiary: '#ffffff'
  tertiary-container: '#17008c'
  on-tertiary-container: '#837fff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d1e4ff'
  primary-fixed-dim: '#b0c9e8'
  on-primary-fixed: '#011d35'
  on-primary-fixed-variant: '#314863'
  secondary-fixed: '#89f5e7'
  secondary-fixed-dim: '#6bd8cb'
  on-secondary-fixed: '#00201d'
  on-secondary-fixed-variant: '#005049'
  tertiary-fixed: '#e2dfff'
  tertiary-fixed-dim: '#c3c0ff'
  on-tertiary-fixed: '#0f0069'
  on-tertiary-fixed-variant: '#3323cc'
  background: '#f8f9ff'
  on-background: '#0d1c2f'
  surface-variant: '#d5e3fd'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 26px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.02em
  currency-display:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  currency-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.5rem
  margin: 1rem
  margin-tablet: 2rem
  margin-desktop: auto
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style

### Personality & Vision
The design system targets Thai salaried professionals, freelancers, and first-time tax filers seeking absolute clarity during personal income tax (P.N.D.90/91) calculation and withholding tax (WHT / 50 Tawi) refund planning. The brand posture balances governmental precision with consumer fintech hospitality—approachable, scrupulously reliable, calm, and empowering.

### Design Movement
**Corporate Modern with Fintech Tactility**: A clean, structured canvas combining disciplined 8pt grid metrics, crisp surface separation, and restrained micro-elevations. The visual expression eliminates decorative clutter, prioritizing numerical legibility, real-time feedback, and clear step-by-step progress through complex statutory deduction categories.

### Emotional Target
- **Confidence & Accuracy:** Eliminates dread surrounding tax math and audit ambiguity.
- **Relief & Delight:** Clear, luminous representation of refund potential ("Money back in your pocket").
- **Clarity over Density:** Tax law translated into digestible, collapsible modules without sacrificing detail.

## Colors

The palette leverages a deep maritime navy to evoke fiscal authority and stability, paired with an emerald/teal spectrum engineered to symbolize legitimate tax savings and withholding refunds. Neutral slates provide calm structural hierarchy, while controlled coral and indigo accents isolate calculation deltas and interactive inputs.

### Palette Architecture
- **Primary Navy (`#0F2942`):** Brand anchor; applied to primary navigation headers, primary CTA states, active tab markers, and high-level tax liability figures.
- **Secondary Emerald (`#0D9488` / Accent Refund `#10B981`):** Refund indicator and positive balance metrics. Used for net refund banners, deduction completion checkmarks, and positive delta values.
- **Tertiary Indigo (`#4F46E5`):** Analytical focal point; powers interactive slider thumbs, stepper progress indicators, and deduction category progress bars.
- **Accent Coral (`#F43F5E`):** Additional tax payable state (when tax owed exceeds WHT deducted), warning limits (e.g., exceeding statutory 500k THB combined pension cap), and mandatory field alerts.
- **Neutral Slate Scales:**
  - Base Ink: `#0F172A` (Headings, primary financial digits)
  - Body Text: `#334155` (Subheadings, field labels, Thai instructional copy)
  - Muted Text: `#64748B` (Secondary descriptions, allowance conditions, deduction ceilings)
  - Surface Hairline: `#E2E8F0` (Borders, divider rules, subtle inset outlines)
  - Surface Background: `#F8FAFC` (Canvas background, neutral card fills)
  - Pure Surface: `#FFFFFF` (Primary elevated cards, sheets, sticky bottom bars)

## Typography

Typography relies on **Plus Jakarta Sans**, chosen for its crisp geometric structure, open counters, and tabular numeral support that pairs harmoniously with modern Thai typefoundry system fallbacks (`Prompt`, `Sarabun`, and standard system `-apple-system, BlinkMacSystemFont`).

### Typography Rules
- **Tabular Figures:** Always apply `font-variant-numeric: tabular-nums` to financial data, input fields, calculation summaries, and deduction breakdowns to prevent jitter during live recalculations.
- **Thai & Latin Harmony:** Maintain an 1.45–1.55 line-height ratio on body copy to accommodate Thai tone marks and ascenders/descenders gracefully without vertical clipping.
- **Numeric Hierarchy:** Financial figures must be visually weighted over the Thai currency sign (฿) and descriptive labels; use `currency-display` with a trailing `THB` or leading `฿` in `label-md`.

## Layout & Spacing

### Mobile-First Layout Model
The layout adheres to a fixed-max-width fluid mobile web structure. The main canvas centers automatically on desktop displays with a constrained max-width of `480px` for mobile app fidelity, or expands to an 8-column layout (`768px`) on tablets and desktop widescreen screens with a dual-pane view (left: input cards, right: sticky live calculation rail).

### Breakpoints & Adaptations
- **Mobile (<640px):** 4 columns. Gutter: `1rem` (`16px`). Canvas margin: `1rem` (`16px`). Real-time summary collapses into a persistent sticky bottom drawer.
- **Tablet / Desktop (>=640px):** 8/12 columns. Fixed maximum container width: `960px`. Screen margin: Auto-centered. Deduction inputs flow along a main content column (65% width) while the tax refund breakdown anchors in an elevated sticky sidebar (35% width).

### Spacing Scale
- `space-xs` (4px): Micro-spacing between labels and hint tooltips; gap between Thai Baht symbols and values.
- `space-sm` (8px): Spacing inside compact pill chips, icon-to-label gaps, and input subtext offsets.
- `space-md` (12px): Padding inside deduction row items; form control vertical stacking.
- `space-lg` (16px): Card internal padding, stepper step separation, accordion header spacing.
- `space-xl` (24px): Inter-card gap; section transitions between income, deductions, and withholding tax entry.

## Elevation & Depth

This design system eschews theatrical heavy drop shadows in favor of crisp financial tonal surfaces and faint, color-tinted ambient occlusion shadows.

### Elevation Hierarchy
- **Level 0 (Canvas):** Tone `#F8FAFC`. Zero elevation. Houses background structure and section divider regions.
- **Level 1 (Default Card & Accordion):** Pure `#FFFFFF` surface bounded by a single structural hairline `1px solid #E2E8F0`. Shadow: `0px 1px 3px rgba(15, 41, 66, 0.04), 0px 1px 2px rgba(15, 41, 66, 0.02)`.
- **Level 2 (Active/Expanded Module & Inputs):** Pure `#FFFFFF` with boosted definition. Applied when a deduction card (e.g., SSF/RMF investment) expands. Border transitions to `#CBD5E1`. Shadow: `0px 4px 6px -1px rgba(15, 41, 66, 0.06), 0px 2px 4px -2px rgba(15, 41, 66, 0.04)`.
- **Level 3 (Sticky Bottom Calculation Sheet & Modals):** Pure `#FFFFFF` with a top surface highlight. Shadow: `0px -4px 16px -2px rgba(15, 41, 66, 0.08), 0px -2px 6px -1px rgba(15, 41, 66, 0.03)`.
- **Refund Highlight Surface:** Tinted surface `#F0FDF4` (50 Emerald tint) framed with a subtle border `1px solid #A7F3D0` for net refund notifications, creating immediate depth through color temperature rather than elevation blur.

## Shapes

The design uses `roundedness: 2` (base `0.5rem` / `8px`) to project a balanced fintech aura—friendly enough for non-accountant end users, yet sharp and disciplined enough for rigorous legal calculations.

### Corner Radii Implementations
- **Base Components (`0.5rem` / `8px`):** Input fields, form select triggers, accordion wrappers, step indicators, and small deduction summary chips.
- **Cards & Sheets (`1rem` / `16px`):** Main income inputs, tax bracket summary cards, and category containers.
- **Overlays & Drawers (`1.5rem` / `24px` top corners):** Bottom sheet calculation breakdowns and full tax breakdown modals.
- **Pill Counters (`9999px`):** Status indicators, deduction tags (`e-Receipt`, `ประกันสังคม`, `SSF/RMF`), and toggle switch buttons.

## Components

### 1. Buttons & Interaction Triggers
- **Primary CTA:** Solid Deep Navy (`#0F2942`) background, crisp white text, `8px` radius, `48px` minimum height on mobile. Hover/Active: `#1E3A5F`. Tap compression scale: `0.98`.
- **Refund Positive CTA:** Emerald Green (`#0D9488`), white text, used strictly for final actions like "View Tax Filing Guide" or "Export 50 Tawi Summary".
- **Ghost/Tertiary Action:** Borderless `#334155` text with `space-sm` icon pairing; used for resetting form states or viewing legal deduction exemption limits.

### 2. Form Inputs & Number Keypads
- **Currency Field Component:** Prefixed with a fixed `฿` symbol in `#64748B`. Large numeric entry (`20px` bold, tabular numerals). Resting border `1px solid #CBD5E1`; focus border `2px solid #0F2942` with an ambient glow (`box-shadow: 0 0 0 3px rgba(15, 41, 66, 0.1)`).
- **Fast-Select Quick Chips:** Horizontal scroll of monetary chips (`+10,000`, `+50,000`, `Max Cap`) below inputs with `#F1F5F9` background and `#334155` text to accelerate input on touch devices.

### 3. Collapsible Deduction Accordion Cards
- **Header:** Contains category title (e.g., "หมวด 2: ประกัน เงินออม และการลงทุน"), real-time utilized deduction sum (e.g., `฿100,000 / ฿100,000`), a circular progress micro-indicator, and a smooth rotational chevron (`180deg`).
- **Body:** Reveals isolated deduction inputs with statutory caps displayed as caption text (e.g., "กองทุน SSF: สูงสุดไม่เกิน 30% ของเงินได้ และไม่เกิน 200,000 บาท").

### 4. Real-Time Sticky Summary Bar (Mobile)
- Positioned fixed to the bottom viewport (`bottom: 0`, left/right `0`).
- Features a dual-metric split:
  - Left: Total Taxable Income (`เงินได้สุทธิ`) and Calculated Tax (`ภาษีที่คำนวณได้`).
  - Right: Net Withholding Refund Status (`คืนภาษีสุทธิ` in `#0D9488` with upward trend indicator) or Tax Owed (`ชำระเพิ่ม` in `#F43F5E`).
- Drag-handle or tap toggles a half-height sheet revealing the progressive bracket steps (0% to 35%).

### 5. Selection Chips & Deduction Toggles
- **Radio/Checkbox Tiers:** Pill-shaped chips for marital status, child allowances, and parent disability options. Selected: Border `1.5px solid #0D9488`, background `#F0FDFA`, label `#0D9488`. Unselected: Border `1px solid #E2E8F0`, background `#FFFFFF`.

### 6. Tax Bracket Visualizer
- A segmented horizontal meter illustrating the 7 Thai progressive tax tiers (0% to 35%). Filled proportion dynamically reflects current taxable net income, spotlighting the user's marginal tax rate bracket.